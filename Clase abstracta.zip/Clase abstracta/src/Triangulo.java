public class Triangulo implements Figura, Linea{

    public Triangulo(String tipo){

    }
    @Override
    public double calcularPermimetro() {
        return 0;
    }

    @Override
    public double calcularArea() {
        return 0;
    }

    @Override
    public double calcularLongitud() {
        return 0;
    }
}
