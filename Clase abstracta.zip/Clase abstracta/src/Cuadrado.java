import javax.sound.sampled.Line;

public class Cuadrado implements Figura, Linea {
    @Override
    public double calcularArea() {
        return 0;
    }

    @Override
    public double calcularPermimetro() {
        return 0;
    }

    @Override
    public double calcularLongitud() {
        return 0;
    }
}
