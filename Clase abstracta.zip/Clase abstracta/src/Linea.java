public interface Linea {
    public double calcularLongitud();
}
