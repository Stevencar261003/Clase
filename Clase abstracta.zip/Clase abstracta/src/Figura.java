public interface Figura {

    public String tipo="";

    public double calcularArea();

    public double calcularPermimetro();



}
